import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class SurveyAccessCreateDto {
  @IsString()
  @IsOptional()
  surveyId?: string

  @IsString()
  @IsOptional()
  participantId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class SurveyAccessUpdateDto {
  @IsString()
  @IsOptional()
  surveyId?: string

  @IsString()
  @IsOptional()
  participantId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
